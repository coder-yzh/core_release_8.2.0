mgen input sink.mgen output mgen_${node.name}.log
